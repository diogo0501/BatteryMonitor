package business;

import javax.persistence.Entity;

public class RegularActivity {
	
	//TODO

	
}
