package business;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class OcasionalActivity extends Activity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//TODO

	
}
