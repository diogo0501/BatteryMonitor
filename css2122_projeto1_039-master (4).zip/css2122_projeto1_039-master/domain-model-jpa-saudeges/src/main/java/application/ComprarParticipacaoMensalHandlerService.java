package application;

import facade.handlers.ComprarParticipacaoMensalHandler;

public class ComprarParticipacaoMensalHandlerService {
	
	private ComprarParticipacaoMensalHandler comprarParticipacaoMensalHandler;

	public ComprarParticipacaoMensalHandlerService(ComprarParticipacaoMensalHandler comprarParticipacaoMensalHandler) {
		this.comprarParticipacaoMensalHandler = comprarParticipacaoMensalHandler;
	}

}