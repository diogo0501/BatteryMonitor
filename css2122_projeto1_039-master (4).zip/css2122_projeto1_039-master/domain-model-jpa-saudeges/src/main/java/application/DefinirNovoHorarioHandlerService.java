package application;

import facade.handlers.DefinirNovoHorarioHandler;

public class DefinirNovoHorarioHandlerService {
	
	private DefinirNovoHorarioHandler definirNovoHorarioHandler;

	public DefinirNovoHorarioHandlerService(DefinirNovoHorarioHandler definirNovoHorarioHandler) {
		this.definirNovoHorarioHandler = definirNovoHorarioHandler;
	}

}
