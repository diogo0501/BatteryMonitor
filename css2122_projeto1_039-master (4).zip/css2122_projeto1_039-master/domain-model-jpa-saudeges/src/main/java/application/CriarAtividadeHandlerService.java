package application;

import facade.handlers.CriarAtividadeHandler;

public class CriarAtividadeHandlerService {
	
	private CriarAtividadeHandler criarAtividadeHandler;

	public CriarAtividadeHandlerService(CriarAtividadeHandler criarAtividadeHandler) {
		this.criarAtividadeHandler = criarAtividadeHandler;
	}

}
