package application;

import facade.handlers.AgendarAtividadeOcasionalHandler;

public class AgendarAtividadeOcasionalHandlerService {
	
	private AgendarAtividadeOcasionalHandler agendarAtividadeOcasionalHandler;

	public AgendarAtividadeOcasionalHandlerService(AgendarAtividadeOcasionalHandler agendarAtividadeOcasionalHandler) {
		this.agendarAtividadeOcasionalHandler = agendarAtividadeOcasionalHandler;
	}

}